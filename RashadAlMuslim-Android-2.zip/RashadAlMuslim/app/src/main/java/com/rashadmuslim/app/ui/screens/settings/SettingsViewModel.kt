package com.rashadmuslim.app.ui.screens.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rashadmuslim.app.data.AdhanPreferencesRepository
import com.rashadmuslim.app.data.AdhanSettings
import com.rashadmuslim.app.data.PrayerKey
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = AdhanPreferencesRepository(app)

    val settings: StateFlow<AdhanSettings?> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setNotificationsEnabled(enabled) }
    }

    fun setPrayerEnabled(prayer: PrayerKey, enabled: Boolean) {
        viewModelScope.launch { repository.setPrayerEnabled(prayer, enabled) }
    }

    fun setCustomSoundUri(uri: String?) {
        viewModelScope.launch { repository.setCustomSoundUri(uri) }
    }
}
