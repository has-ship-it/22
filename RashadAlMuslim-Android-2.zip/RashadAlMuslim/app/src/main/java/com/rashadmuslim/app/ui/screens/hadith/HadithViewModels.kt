package com.rashadmuslim.app.ui.screens.hadith

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rashadmuslim.app.data.model.HADITH_BOOKS
import com.rashadmuslim.app.data.model.HadithItem
import com.rashadmuslim.app.data.repository.HadithRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface HadithListUiState {
    data object Loading : HadithListUiState
    data class Success(val hadiths: List<HadithItem>, val fromCache: Boolean) : HadithListUiState
    data class Error(val message: String) : HadithListUiState
}

/** قائمة الكتب الستة ثابتة محليًا (لا تحتاج شبكة)، تُعرض في الشاشة الرئيسية للحديث. */
class HadithBooksViewModel : ViewModel() {
    val books = HADITH_BOOKS
}

class HadithBookViewModel(app: Application, private val savedStateHandle: SavedStateHandle) : AndroidViewModel(app) {

    private val repository = HadithRepository(app)
    private val slug: String = checkNotNull(savedStateHandle["bookSlug"])

    private val _state = MutableStateFlow<HadithListUiState>(HadithListUiState.Loading)
    val state: StateFlow<HadithListUiState> = _state

    init { load() }

    fun load() {
        _state.value = HadithListUiState.Loading
        viewModelScope.launch {
            repository.getBook(slug)
                .onSuccess { _state.value = HadithListUiState.Success(it.hadiths, it.fromCache) }
                .onFailure { _state.value = HadithListUiState.Error(it.message ?: "تعذّر تحميل الكتاب. تحقق من الإنترنت.") }
        }
    }
}
