package com.rashadmuslim.app.ui.screens.ramadan

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.QURAN_TOTAL_JUZ
import com.rashadmuslim.app.data.RamadanRepository
import com.rashadmuslim.app.ui.screens.prayer.PrayerUiState
import com.rashadmuslim.app.ui.screens.prayer.PrayerViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RamadanViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = RamadanRepository(app)

    val juzRead: StateFlow<Int> = repo.juzReadFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun increment() = viewModelScope.launch { repo.incrementJuz() }
    fun decrement() = viewModelScope.launch {
        val current = juzRead.value
        repo.setJuzRead((current - 1).coerceAtLeast(0))
    }
    fun reset() = viewModelScope.launch { repo.resetJuz() }
}

private data class RamadanNote(val title: String, val body: String)

private val RAMADAN_NOTES = listOf(
    RamadanNote(
        "السحور",
        "يُستحب تأخير السحور قريبًا من أذان الفجر، وهو وقت بركة ونشاط للصائم."
    ),
    RamadanNote(
        "الإفطار",
        "يُسن تعجيل الإفطار عند دخول وقت المغرب، والبدء بتمر أو ماء إن وجد."
    ),
    RamadanNote(
        "قيام الليل والتراويح",
        "صلاة التراويح من السنن المرغّبة في رمضان، وتُصلّى جماعة في المساجد عادة بعد صلاة العشاء."
    ),
    RamadanNote(
        "زكاة الفطر",
        "تجب زكاة الفطر على كل مسلم قادر، تؤدّى قبل صلاة عيد الفطر، ومقدارها صاع من طعام غالب قوت البلد (أو ما يعادله)، وتفاصيل جواز إخراجها نقدًا موضع خلاف فقهي معتبر بين العلماء."
    )
)

@Composable
fun RamadanScreen(
    viewModel: RamadanViewModel = viewModel(),
    prayerViewModel: PrayerViewModel = viewModel()
) {
    val juzRead by viewModel.juzRead.collectAsState()
    val prayerState by prayerViewModel.state.collectAsState()

    LaunchedEffect(Unit) { prayerViewModel.load() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("رمضان", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        LazyColumn(Modifier.padding(padding)) {
            item {
                SuhoorIftarCard(prayerState)
            }
            item {
                KhatmahCard(
                    juzRead = juzRead,
                    onIncrement = { viewModel.increment() },
                    onDecrement = { viewModel.decrement() },
                    onReset = { viewModel.reset() }
                )
            }
            items(RAMADAN_NOTES) { note ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(note.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            note.body,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SuhoorIftarCard(state: PrayerUiState) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("مواقيت السحور والإفطار", style = MaterialTheme.typography.titleMedium)
            when (state) {
                is PrayerUiState.Loading -> Text(
                    "جارٍ تحديد الموقع وجلب المواقيت...",
                    modifier = Modifier.padding(top = 8.dp)
                )
                is PrayerUiState.Error -> Text(
                    state.message,
                    modifier = Modifier.padding(top = 8.dp)
                )
                is PrayerUiState.Success -> {
                    val fajr = state.timings.firstOrNull { it.first == "الفجر" }?.second ?: "--:--"
                    val maghrib = state.timings.firstOrNull { it.first == "المغرب" }?.second ?: "--:--"
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("إمساك السحور (الفجر)", style = MaterialTheme.typography.bodySmall)
                            Text(fajr, style = MaterialTheme.typography.headlineSmall)
                        }
                        Column {
                            Text("الإفطار (المغرب)", style = MaterialTheme.typography.bodySmall)
                            Text(maghrib, style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KhatmahCard(
    juzRead: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onReset: () -> Unit
) {
    val progress = juzRead.toFloat() / QURAN_TOTAL_JUZ.toFloat()

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("متابعة ختمة القرآن", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDecrement) {
                        Icon(Icons.Filled.Remove, contentDescription = "تقليل")
                    }
                    Text(
                        "$juzRead / $QURAN_TOTAL_JUZ جزءًا",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(onClick = onIncrement) {
                        Icon(Icons.Filled.Add, contentDescription = "زيادة")
                    }
                }
                CircularProgressIndicator(progress = { progress })
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onReset) { Text("إعادة تعيين") }
            }
            Text(
                "متابعة شخصية محلية فقط لتقدّمك في قراءة القرآن خلال الشهر، لا تُستخدم للمقارنة مع غيرك.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}
