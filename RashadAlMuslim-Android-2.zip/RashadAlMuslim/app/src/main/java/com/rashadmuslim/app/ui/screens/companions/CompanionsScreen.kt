package com.rashadmuslim.app.ui.screens.companions

import android.app.Application
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.Companion as CompanionModel
import com.rashadmuslim.app.data.repository.EducationalContentRepository

class CompanionsViewModel(app: Application) : AndroidViewModel(app) {
    val companions = EducationalContentRepository(app).loadCompanions().companions
}

@Composable
fun CompanionsScreen(viewModel: CompanionsViewModel = viewModel()) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, viewModel.companions) {
        if (query.isBlank()) viewModel.companions
        else viewModel.companions.filter { it.name.contains(query) || it.title.contains(query) }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("موسوعة الصحابة", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("ابحث عن صحابي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            Text(
                "مجموعة أولية تمثيلية من أشهر الصحابة رضي الله عنهم — ستُستكمل بأسماء أخرى تدريجيًا.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(horizontal = 16.dp, bottom = 8.dp)
            )
            LazyColumn {
                items(filtered, key = { it.id }) { companion ->
                    CompanionCard(companion)
                }
            }
        }
    }
}

@Composable
private fun CompanionCard(companion: CompanionModel) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .animateContentSize()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(companion.name, style = MaterialTheme.typography.titleMedium)
            Text(companion.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            if (expanded) {
                Text(companion.bio, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                Text(
                    "أبرز الأحداث: ${companion.notableEvents}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 6.dp)
                )
                Text(
                    companion.sourceNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
