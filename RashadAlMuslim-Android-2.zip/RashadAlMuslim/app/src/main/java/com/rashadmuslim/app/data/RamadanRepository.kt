package com.rashadmuslim.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.ramadanDataStore by preferencesDataStore(name = "ramadan_tracker")

/** إجمالي عدد أجزاء القرآن الكريم، تُستخدم لحساب نسبة تقدّم الختمة. */
const val QURAN_TOTAL_JUZ = 30

/**
 * تتبّع محلي بسيط لتقدّم ختمة رمضان (عدد الأجزاء المقروءة)، يعمل دون إنترنت ودون أي
 * مزامنة أو مشاركة مع غيره من المستخدمين.
 */
class RamadanRepository(private val context: Context) {

    private object Keys {
        val JUZ_READ = intPreferencesKey("ramadan_juz_read")
    }

    val juzReadFlow: Flow<Int> = context.ramadanDataStore.data.map { it[Keys.JUZ_READ] ?: 0 }

    suspend fun setJuzRead(value: Int) {
        val clamped = value.coerceIn(0, QURAN_TOTAL_JUZ)
        context.ramadanDataStore.edit { prefs -> prefs[Keys.JUZ_READ] = clamped }
    }

    suspend fun incrementJuz() {
        context.ramadanDataStore.edit { prefs ->
            val current = prefs[Keys.JUZ_READ] ?: 0
            prefs[Keys.JUZ_READ] = (current + 1).coerceAtMost(QURAN_TOTAL_JUZ)
        }
    }

    suspend fun resetJuz() {
        context.ramadanDataStore.edit { prefs -> prefs[Keys.JUZ_READ] = 0 }
    }
}
