package com.rashadmuslim.app.data.repository

import android.content.Context
import com.rashadmuslim.app.data.local.AppDatabase
import com.rashadmuslim.app.data.local.HadithBookCacheEntity
import com.rashadmuslim.app.data.local.toJsonOrNull
import com.rashadmuslim.app.data.local.toSectionMapOrNull
import com.rashadmuslim.app.data.model.HadithItem
import com.rashadmuslim.app.network.NetworkModule
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class HadithBookContent(
    val hadiths: List<HadithItem>,
    val sectionNames: Map<String, String>?,
    val fromCache: Boolean
)

class HadithRepository(private val context: Context) {

    private val api = NetworkModule.hadithApi
    private val dao by lazy { AppDatabase.get(context).hadithCacheDao() }
    private val gson = Gson()

    /** يحاول الشبكة أولًا (ويحدّث الذاكرة المحلية بنجاحه)، ويسقط تلقائيًا إلى النسخة
     * المخزّنة محليًا عند فشل الاتصال — هذا ما يجعل قراءة كتاب فُتح سابقًا يعمل دون إنترنت. */
    suspend fun getBook(slug: String): Result<HadithBookContent> = withContext(Dispatchers.IO) {
        try {
            val response = api.getEdition(slug)
            dao.put(
                HadithBookCacheEntity(
                    slug = slug,
                    hadithsJson = gson.toJson(response.hadiths),
                    sectionNamesJson = response.metadata.section.toJsonOrNull(),
                    cachedAtMillis = System.currentTimeMillis()
                )
            )
            Result.success(
                HadithBookContent(response.hadiths, response.metadata.section, fromCache = false)
            )
        } catch (e: Exception) {
            val cached = dao.get(slug)
            if (cached != null) {
                val type = object : TypeToken<List<HadithItem>>() {}.type
                val hadiths: List<HadithItem> = gson.fromJson(cached.hadithsJson, type)
                Result.success(
                    HadithBookContent(hadiths, cached.sectionNamesJson.toSectionMapOrNull(), fromCache = true)
                )
            } else {
                Result.failure(e)
            }
        }
    }
}
