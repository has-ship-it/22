package com.rashadmuslim.app.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.rashadmuslim.app.data.model.HadithItem

/**
 * تخزين محلي بسيط (Room) لملفات الحديث بعد جلبها، بحيث تعمل لاحقًا دون إنترنت.
 * كل كتاب يُخزَّن كصف واحد يحمل قائمة الأحاديث كاملة بصيغة JSON — كافٍ لحجم هذه البيانات
 * ويغنينا عن تصميم مخطط علاقي معقّد في هذه المرحلة المبكرة.
 */
@Entity(tableName = "hadith_books_cache")
data class HadithBookCacheEntity(
    @PrimaryKey val slug: String,
    val hadithsJson: String,
    val sectionNamesJson: String?,
    val cachedAtMillis: Long
)

class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromHadithList(list: List<HadithItem>): String = gson.toJson(list)

    @TypeConverter
    fun toHadithList(json: String): List<HadithItem> {
        val type = object : TypeToken<List<HadithItem>>() {}.type
        return gson.fromJson(json, type)
    }
}

@Dao
interface HadithCacheDao {
    @Query("SELECT * FROM hadith_books_cache WHERE slug = :slug LIMIT 1")
    suspend fun get(slug: String): HadithBookCacheEntity?

    @androidx.room.Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    suspend fun put(entity: HadithBookCacheEntity)
}

@Database(entities = [HadithBookCacheEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun hadithCacheDao(): HadithCacheDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "rashad_almuslim.db"
            ).build().also { instance = it }
        }
    }
}

/** تحويل بسيط لتخزين خريطة أسماء الأبواب (section) كنص JSON داخل نفس الصف. */
fun Map<String, String>?.toJsonOrNull(): String? =
    if (this == null) null else Gson().toJson(this)

fun String?.toSectionMapOrNull(): Map<String, String>? {
    if (this == null) return null
    val type = object : TypeToken<Map<String, String>>() {}.type
    return Gson().fromJson(this, type)
}
