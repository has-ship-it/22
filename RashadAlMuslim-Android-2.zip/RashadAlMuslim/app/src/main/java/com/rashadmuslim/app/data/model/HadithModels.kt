package com.rashadmuslim.app.data.model

data class HadithEditionResponse(
    val metadata: HadithMetadata,
    val hadiths: List<HadithItem>
)

data class HadithMetadata(
    val name: String?,
    val section: Map<String, String>?,          // رقم القسم -> اسم الباب بالعربية
    val section_detail: Map<String, SectionDetail>?
)

data class SectionDetail(
    val hadithnumber_first: Int?,
    val hadithnumber_last: Int?
)

data class HadithItem(
    val hadithnumber: Int,
    val arabicnumber: Int?,
    val text: String,
    val grades: List<HadithGrade>?,
    val reference: HadithReference?
)

data class HadithGrade(
    val name: String?,   // اسم من درَّج الحديث (مثل: Al-Albani)
    val grade: String?   // الدرجة (Sahih, Hasan, Da'if...)
)

data class HadithReference(
    val book: Int?,
    val hadith: Int?
)

/** الكتب الستة الكبرى — كل عنصر يحمل اسم إصدار النص العربي في fawazahmed0/hadith-api. */
data class HadithBook(val slug: String, val arabicName: String, val shortDesc: String)

val HADITH_BOOKS = listOf(
    HadithBook("ara-bukhari", "صحيح البخاري", "أصح كتاب بعد القرآن الكريم"),
    HadithBook("ara-muslim1", "صحيح مسلم", "ثاني أصح الكتب الحديثية"),
    HadithBook("ara-abudawud", "سنن أبي داود", "من كتب السنن الأربعة"),
    HadithBook("ara-tirmidhi", "جامع الترمذي", "يُعنى ببيان درجة الحديث غالبًا"),
    HadithBook("ara-nasai", "سنن النسائي", "من كتب السنن الأربعة"),
    HadithBook("ara-ibnmajah", "سنن ابن ماجه", "من كتب السنن الأربعة"),
)

/** يترجم رمز الدرجة في الـ API إلى عبارة عربية مختصرة للعرض. */
fun List<HadithGrade>?.toArabicGradeSummary(): String {
    val grade = this?.firstOrNull { !it.grade.isNullOrBlank() }?.grade ?: return "غير مصنّفة ضمن هذا المصدر"
    val normalized = grade.lowercase()
    return when {
        "sahih" in normalized -> "صحيح"
        "hasan" in normalized -> "حسن"
        "da'if" in normalized || "daif" in normalized || "weak" in normalized -> "ضعيف"
        else -> grade
    }
}
