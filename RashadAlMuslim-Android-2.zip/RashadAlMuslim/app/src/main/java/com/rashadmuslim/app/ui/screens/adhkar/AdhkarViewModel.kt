package com.rashadmuslim.app.ui.screens.adhkar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.rashadmuslim.app.data.model.AdhkarCategory
import com.rashadmuslim.app.data.repository.AdhkarRepository

class AdhkarViewModel(app: Application) : AndroidViewModel(app) {
    val categories: List<AdhkarCategory> = AdhkarRepository(app).loadAll().categories
}
