package com.rashadmuslim.app.ui.screens.seerah

import android.app.Application
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.SeerahEvent
import com.rashadmuslim.app.data.repository.EducationalContentRepository

class SeerahViewModel(app: Application) : AndroidViewModel(app) {
    val events = EducationalContentRepository(app).loadSeerah().events
}

@Composable
fun SeerahScreen(viewModel: SeerahViewModel = viewModel()) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("السيرة النبوية", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxWidth().padding(padding).padding(vertical = 8.dp)) {
            items(viewModel.events, key = { it.id }) { event ->
                TimelineRow(event)
            }
        }
    }
}

@Composable
private fun TimelineRow(event: SeerahEvent) {
    var expanded by remember { mutableStateOf(false) }

    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(12.dp).background(MaterialTheme.colorScheme.secondary, CircleShape)
            )
            Box(
                Modifier
                    .width(2.dp)
                    .weight(1f)
                    .padding(top = 2.dp)
                    .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            )
        }
        Column(
            Modifier
                .padding(start = 14.dp, bottom = 22.dp)
                .animateContentSize()
                .clickable { expanded = !expanded }
        ) {
            Text(event.periodLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            Text(event.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 2.dp))
            if (expanded) {
                Text(event.summary, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
                Text(
                    event.sourceNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
