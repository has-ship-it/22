package com.rashadmuslim.app.ui.screens.adhkar

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.AdhkarItem

@Composable
fun AdhkarScreen(viewModel: AdhkarViewModel = viewModel()) {
    val categories = viewModel.categories
    var selected by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("الأذكار", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            ScrollableTabRow(selectedTabIndex = selected) {
                categories.forEachIndexed { index, cat ->
                    Tab(
                        selected = selected == index,
                        onClick = { selected = index },
                        text = { Text(cat.nameAr) }
                    )
                }
            }
            if (categories.isNotEmpty()) {
                LazyColumn {
                    items(categories[selected].items, key = { it.text }) { item ->
                        DhikrCard(item)
                    }
                }
            }
        }
    }
}

@Composable
private fun DhikrCard(item: AdhkarItem) {
    var remaining by remember(item) { mutableIntStateOf(item.repeat) }
    val done = remaining <= 0

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (done) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(
                item.text,
                style = MaterialTheme.typography.bodyLarge.copy(lineHeight = 30.sp),
            )
            Text(
                item.source,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(top = 8.dp)
            )
            Box(Modifier.fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
                if (done) {
                    Text("تم إكمال الذكر ✓", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                } else {
                    CounterButton(remaining = remaining, onTap = { remaining-- })
                }
            }
        }
    }
}

@Composable
private fun CounterButton(remaining: Int, onTap: () -> Unit) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clickable(onClick = onTap),
        contentAlignment = Alignment.Center
    ) {
        Card(shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
            Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                Text("$remaining", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
