package com.rashadmuslim.app.ui.screens.profile

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rashadmuslim.app.data.ProfileStats
import com.rashadmuslim.app.data.ProfileStatsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProfileViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = ProfileStatsRepository(app)

    val stats: StateFlow<ProfileStats> = repository.statsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProfileStats(0, 0, 0))

    init {
        viewModelScope.launch { repository.recordAppOpenIfNewDay() }
    }
}

@Composable
fun ProfileScreen(viewModel: ProfileViewModel = viewModel()) {
    val stats by viewModel.stats.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("الملف الشخصي", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Column(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                        Text("🧕", style = MaterialTheme.typography.headlineSmall)
                    }
                }
                Text("مستخدم رشاد المسلم", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 10.dp))
            }

            Text(
                "إحصائياتك الخاصة — محفوظة على جهازك فقط، ولا تُستخدم للمقارنة مع غيرك.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            StatRow("أيام الاستخدام", stats.daysUsed)
            StatRow("الأذكار المكتملة", stats.dhikrCompleted)
            StatRow("الأحاديث المقروءة", stats.hadithsRead)

            Text(
                "ملاحظة: بعض الإحصائيات (كالختمات والدروس) ستُضاف تدريجيًا مع إكمال أقسام الحفظ والأكاديمية.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}

@Composable
private fun StatRow(label: String, value: Int) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("$value", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
        }
    }
}
