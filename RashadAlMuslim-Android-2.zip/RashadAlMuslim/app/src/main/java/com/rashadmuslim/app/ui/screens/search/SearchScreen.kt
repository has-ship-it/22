package com.rashadmuslim.app.ui.screens.search

import android.app.Application
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.repository.EducationalContentRepository

private data class SearchHit(val category: String, val title: String, val snippet: String)

class SearchViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = EducationalContentRepository(app)

    // البيانات ثابتة محليًا وخفيفة، فتُحمَّل مرة واحدة دون حاجة لمعالجة غير متزامنة
    val allItems: List<SearchHit> = buildList {
        repo.loadFiqh().topics.forEach { topic ->
            topic.issues.forEach { issue ->
                add(SearchHit("الفقه", issue.title, issue.ruling))
            }
        }
        repo.loadAqeedah().units.forEach { unit ->
            add(SearchHit("العقيدة", unit.nameAr, unit.summary))
        }
        repo.loadSeerah().events.forEach { event ->
            add(SearchHit("السيرة", event.title, event.summary))
        }
    }
}

@Composable
fun SearchScreen(viewModel: SearchViewModel = viewModel()) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    val categories = listOf("الكل", "الفقه", "العقيدة", "السيرة")

    val results = remember(query, selectedTab) {
        viewModel.allItems.filter { hit ->
            (selectedTab == 0 || categories[selectedTab] == hit.category) &&
                (query.isBlank() || hit.title.contains(query) || hit.snippet.contains(query))
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("البحث الإسلامي", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("ابحث في الفقه والعقيدة والسيرة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            Text(
                "ملاحظة: البحث هنا يشمل الفقه والعقيدة والسيرة فقط. للبحث داخل كتاب حديث معيّن أو " +
                    "داخل القرآن، افتح القسم المخصص له من القائمة السفلية.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(horizontal = 16.dp, bottom = 8.dp)
            )
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                categories.forEachIndexed { index, label ->
                    Tab(selected = selectedTab == index, onClick = { selectedTab = index }, text = { Text(label) })
                }
            }
            if (query.isBlank()) {
                Text(
                    "اكتب كلمة للبحث",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(results) { hit ->
                        Card(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(hit.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                Text(hit.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 2.dp))
                                Text(
                                    hit.snippet,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.outline,
                                    maxLines = 2,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                    if (results.isEmpty()) {
                        item {
                            Text(
                                "لا نتائج مطابقة",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
