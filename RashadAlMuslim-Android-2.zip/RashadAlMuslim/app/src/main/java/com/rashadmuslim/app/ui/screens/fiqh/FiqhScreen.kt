package com.rashadmuslim.app.ui.screens.fiqh

import android.app.Application
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.FiqhIssue
import com.rashadmuslim.app.data.model.FiqhTopic
import com.rashadmuslim.app.data.repository.EducationalContentRepository

class FiqhViewModel(app: Application) : AndroidViewModel(app) {
    val topics = EducationalContentRepository(app).loadFiqh().topics
}

@Composable
fun FiqhScreen(viewModel: FiqhViewModel = viewModel()) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("الفقه", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxWidth().padding(padding)) {
            items(viewModel.topics, key = { it.id }) { topic ->
                TopicCard(topic)
            }
            item {
                Text(
                    "ملاحظة: هذا شرح مبسط لأغراض تعليمية، وعند وجود خلاف فقهي معتبر يُذكر بإيجاز " +
                        "دون ترجيح رأي على آخر. للمسائل الدقيقة أو الحالات الخاصة يُنصح بمراجعة مختص.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}

@Composable
private fun TopicCard(topic: FiqhTopic) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(topic.nameAr, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            topic.issues.forEachIndexed { index, issue ->
                if (index > 0) HorizontalDivider(Modifier.padding(vertical = 10.dp))
                IssueBlock(issue)
            }
        }
    }
}

@Composable
private fun IssueBlock(issue: FiqhIssue) {
    Column(Modifier.padding(top = 10.dp)) {
        Text(issue.title, style = MaterialTheme.typography.titleMedium)
        Text(
            "الحكم: ${issue.ruling}",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 6.dp)
        )
        Text(
            "الأدلة: ${issue.evidenceSummary}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
            modifier = Modifier.padding(top = 4.dp)
        )
        issue.scholarlyDifference?.let {
            Text(
                "عند الاختلاف الفقهي: $it",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
