package com.rashadmuslim.app.data.model

data class TimingsResponse(
    val code: Int,
    val status: String,
    val data: TimingsData
)

data class TimingsData(
    val timings: Timings,
    val date: DateInfo
)

// الأوقات تأتي كنص "HH:mm" (وقد تحتوي أحيانًا على منطقة زمنية، لذا تُقص لاحقًا عند العرض)
data class Timings(
    val Fajr: String,
    val Sunrise: String,
    val Dhuhr: String,
    val Asr: String,
    val Maghrib: String,
    val Isha: String
)

data class DateInfo(
    val readable: String,
    val hijri: HijriDate?
)

data class HijriDate(
    val date: String,
    val month: HijriMonth,
    val year: String
)

data class HijriMonth(
    val ar: String
)

data class QiblaResponse(
    val code: Int,
    val status: String,
    val data: QiblaData
)

data class QiblaData(
    val latitude: Double,
    val longitude: Double,
    val direction: Double  // درجة الاتجاه نحو الكعبة (بالنسبة للشمال الجغرافي)، بالساعة دورانًا
)

/** يحوّل خريطة الأوقات الخام إلى قائمة مرتبة بأسمائها العربية لعرضها في الواجهة. */
fun Timings.toOrderedArabicList(): List<Pair<String, String>> = listOf(
    "الفجر" to Fajr.take(5),
    "الشروق" to Sunrise.take(5),
    "الظهر" to Dhuhr.take(5),
    "العصر" to Asr.take(5),
    "المغرب" to Maghrib.take(5),
    "العشاء" to Isha.take(5),
)

data class NextPrayerInfo(val name: String, val time: String, val remainingMillis: Long)

/** يحدد أقرب صلاة لم يحن وقتها بعد من قائمة اليوم الحالي (الصلوات الخمس فقط، دون الشروق). */
fun List<Pair<String, String>>.findNextPrayer(): NextPrayerInfo? {
    val now = java.util.Calendar.getInstance()
    val fivePrayers = filter { it.first != "الشروق" }
    for ((name, hhmm) in fivePrayers) {
        val parts = hhmm.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: continue
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: continue
        val target = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
        }
        if (target.after(now)) {
            return NextPrayerInfo(name, hhmm, target.timeInMillis - now.timeInMillis)
        }
    }
    // كل صلوات اليوم انتهت: الصلاة القادمة هي فجر الغد (تقديريًا بنفس وقت فجر اليوم)
    val fajr = fivePrayers.firstOrNull { it.first == "الفجر" } ?: return null
    val parts = fajr.second.split(":")
    val hour = parts.getOrNull(0)?.toIntOrNull() ?: return null
    val minute = parts.getOrNull(1)?.toIntOrNull() ?: return null
    val tomorrowFajr = java.util.Calendar.getInstance().apply {
        add(java.util.Calendar.DAY_OF_MONTH, 1)
        set(java.util.Calendar.HOUR_OF_DAY, hour)
        set(java.util.Calendar.MINUTE, minute)
        set(java.util.Calendar.SECOND, 0)
    }
    return NextPrayerInfo(fajr.first, fajr.second, tomorrowFajr.timeInMillis - now.timeInMillis)
}

fun Long.toCountdownText(): String {
    val totalSeconds = this / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
