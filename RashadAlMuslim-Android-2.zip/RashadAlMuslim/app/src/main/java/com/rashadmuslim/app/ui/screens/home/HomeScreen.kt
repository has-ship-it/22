package com.rashadmuslim.app.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.findNextPrayer
import com.rashadmuslim.app.data.model.toCountdownText
import com.rashadmuslim.app.ui.screens.prayer.PrayerUiState
import com.rashadmuslim.app.ui.screens.prayer.PrayerViewModel
import kotlinx.coroutines.delay

private data class QuickAccess(val label: String, val icon: ImageVector, val route: String)

private val QUICK_ACCESS = listOf(
    QuickAccess("القرآن", Icons.Filled.MenuBook, "quran_list"),
    QuickAccess("الأذكار", Icons.Filled.FavoriteBorder, "adhkar"),
    QuickAccess("الصلاة", Icons.Filled.Mosque, "prayer"),
    QuickAccess("القبلة", Icons.Filled.Explore, "qibla"),
    QuickAccess("الحديث", Icons.Filled.AutoStories, "hadith_books"),
    QuickAccess("البحث", Icons.Filled.Search, "search"),
)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, prayerViewModel: PrayerViewModel = viewModel()) {
    val prayerState by prayerViewModel.state.collectAsState()

    LaunchedEffect(Unit) { prayerViewModel.load() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("رشاد المسلم", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Text("السلام عليكم ورحمة الله وبركاته", style = MaterialTheme.typography.titleMedium)

            NextPrayerCard(prayerState, onOpenPrayerTimes = { onNavigate("prayer") })

            Text(
                "الوصول السريع",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxWidth(),
                userScrollEnabled = false
            ) {
                items(QUICK_ACCESS) { item ->
                    QuickAccessTile(item, onClick = { onNavigate(item.route) })
                }
            }
        }
    }
}

@Composable
private fun NextPrayerCard(state: PrayerUiState, onOpenPrayerTimes: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("🕌 الصلاة القادمة", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
            when (state) {
                is PrayerUiState.Success -> {
                    val next = state.timings.findNextPrayer()
                    if (next != null) {
                        var remaining by remember(next) { mutableLongStateOf(next.remainingMillis) }
                        LaunchedEffect(next) {
                            while (remaining > 0) {
                                delay(1000)
                                remaining -= 1000
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(top = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(next.name, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineSmall)
                            Text(next.time, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineSmall)
                        }
                        Text(
                            "باقي: ${remaining.coerceAtLeast(0).toCountdownText()}",
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                is PrayerUiState.Loading -> Text(
                    "جارٍ تحديد موقعك…",
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                    modifier = Modifier.padding(top = 10.dp)
                )
                is PrayerUiState.Error -> Text(
                    "فعّل خدمة الموقع لعرض الصلاة القادمة",
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            Button(
                onClick = onOpenPrayerTimes,
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.onPrimary,
                    contentColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
            ) { Text("فتح مواقيت الصلاة") }
        }
    }
}

@Composable
private fun QuickAccessTile(item: QuickAccess, onClick: () -> Unit) {
    Card(
        modifier = Modifier.padding(6.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(item.icon, contentDescription = item.label, tint = MaterialTheme.colorScheme.primary)
            Text(item.label, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
