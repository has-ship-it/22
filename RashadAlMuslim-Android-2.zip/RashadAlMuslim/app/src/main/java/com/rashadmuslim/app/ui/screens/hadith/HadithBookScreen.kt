package com.rashadmuslim.app.ui.screens.hadith

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.HadithItem
import com.rashadmuslim.app.data.model.toArabicGradeSummary
import com.rashadmuslim.app.ui.components.ErrorState
import com.rashadmuslim.app.ui.components.LoadingState

@Composable
fun HadithBookScreen(
    bookArabicName: String,
    onBack: () -> Unit,
    viewModel: HadithBookViewModel = viewModel()
) {
    val state by viewModel.state.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(bookArabicName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "رجوع") }
                }
            )
        }
    ) { padding ->
        when (val s = state) {
            is HadithListUiState.Loading -> LoadingState(Modifier.padding(padding))
            is HadithListUiState.Error -> ErrorState(s.message, onRetry = viewModel::load, modifier = Modifier.padding(padding))
            is HadithListUiState.Success -> Column(Modifier.fillMaxSize().padding(padding)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("ابحث في نص الأحاديث") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
                if (s.fromCache) {
                    Text(
                        "تُعرض نسخة محفوظة محليًا (بلا إنترنت حاليًا)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(horizontal = 16.dp, bottom = 4.dp)
                    )
                }
                val filtered = remember(query, s.hadiths) {
                    if (query.isBlank()) s.hadiths else s.hadiths.filter { it.text.contains(query) }
                }
                HadithList(filtered, PaddingValues(bottom = 16.dp))
            }
        }
    }
}

@Composable
private fun HadithList(hadiths: List<HadithItem>, padding: PaddingValues) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = padding) {
        items(hadiths, key = { it.hadithnumber }) { hadith ->
            HadithCard(hadith)
        }
    }
}

@Composable
private fun HadithCard(hadith: HadithItem) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .animateContentSize()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            // نص الحديث — مفصول بصريًا عن الحكم والمرجع أدناه
            Text(
                hadith.text,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = if (expanded) Int.MAX_VALUE else 3,
                modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 10.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Text(
                    "الحديث رقم ${hadith.arabicnumber ?: hadith.hadithnumber}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (expanded) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "الحكم على الحديث: ${hadith.grades.toArabicGradeSummary()}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    hadith.reference?.let { ref ->
                        Text(
                            "المرجع: الكتاب ${ref.book ?: "—"}، الحديث ${ref.hadith ?: hadith.hadithnumber}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
