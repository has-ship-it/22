package com.rashadmuslim.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.rashadmuslim.app.ui.navigation.RashadNavHost
import com.rashadmuslim.app.ui.theme.RashadAlMuslimTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // اتجاه الواجهة (RTL/LTR) يتبع تلقائيًا لغة التطبيق المختارة في الإعدادات
            // (عربي = RTL، إنجليزي = LTR) عبر إعدادات اللغة لكل تطبيق في أندرويد،
            // دون الحاجة لفرضه يدويًا هنا.
            RashadAlMuslimTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RashadNavHost()
                }
            }
        }
    }
}
