package com.rashadmuslim.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rashadmuslim.app.data.model.HADITH_BOOKS
import com.rashadmuslim.app.ui.screens.adhkar.AdhkarScreen
import com.rashadmuslim.app.ui.screens.aqeedah.AqeedahScreen
import com.rashadmuslim.app.ui.screens.companions.CompanionsScreen
import com.rashadmuslim.app.ui.screens.fiqh.FiqhScreen
import com.rashadmuslim.app.ui.screens.hadith.HadithBookScreen
import com.rashadmuslim.app.ui.screens.hadith.HadithBooksScreen
import com.rashadmuslim.app.ui.screens.hajj.HajjUmrahScreen
import com.rashadmuslim.app.ui.screens.home.HomeScreen
import com.rashadmuslim.app.ui.screens.library.LibraryScreen
import com.rashadmuslim.app.ui.screens.more.MoreScreen
import com.rashadmuslim.app.ui.screens.prayer.PrayerScreen
import com.rashadmuslim.app.ui.screens.profile.ProfileScreen
import com.rashadmuslim.app.ui.screens.qibla.QiblaScreen
import com.rashadmuslim.app.ui.screens.quran.SurahDetailScreen
import com.rashadmuslim.app.ui.screens.quran.SurahListScreen
import com.rashadmuslim.app.ui.screens.ramadan.RamadanScreen
import com.rashadmuslim.app.ui.screens.search.SearchScreen
import com.rashadmuslim.app.ui.screens.seerah.SeerahScreen
import com.rashadmuslim.app.ui.screens.settings.SettingsScreen
import com.rashadmuslim.app.ui.screens.tools.TasbihScreen
import com.rashadmuslim.app.ui.screens.tools.ToolsScreen
import com.rashadmuslim.app.ui.screens.tools.ZakatCalculatorScreen
import java.net.URLEncoder

private sealed class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Home : Tab("home", "الرئيسية", Icons.Filled.Home)
    data object Quran : Tab("quran_list", "القرآن", Icons.Filled.MenuBook)
    data object Adhkar : Tab("adhkar", "الأذكار", Icons.Filled.FavoriteBorder)
    data object Prayer : Tab("prayer", "الصلاة", Icons.Filled.Mosque)
    data object More : Tab("more", "المزيد", Icons.Filled.List)
}

private val tabs = listOf(Tab.Home, Tab.Quran, Tab.Adhkar, Tab.Prayer, Tab.More)

@Composable
fun RashadNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { RashadBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(Tab.Home.route) {
                HomeScreen(onNavigate = { route -> navController.navigate(route) })
            }

            composable(Tab.Quran.route) {
                SurahListScreen(onSurahClick = { number ->
                    navController.navigate("surah_detail/$number")
                })
            }
            composable(
                route = "surah_detail/{surahNumber}",
                arguments = listOf(navArgument("surahNumber") { type = androidx.navigation.NavType.IntType })
            ) {
                SurahDetailScreen(onBack = { navController.popBackStack() })
            }

            composable("hadith_books") {
                HadithBooksScreen(onBookClick = { book ->
                    val encodedName = URLEncoder.encode(book.arabicName, "UTF-8")
                    navController.navigate("hadith_book/${book.slug}/$encodedName")
                })
            }
            composable(
                route = "hadith_book/{bookSlug}/{bookName}",
                arguments = listOf(
                    navArgument("bookSlug") { type = androidx.navigation.NavType.StringType },
                    navArgument("bookName") { type = androidx.navigation.NavType.StringType }
                )
            ) { backStackEntry ->
                val rawName = backStackEntry.arguments?.getString("bookName").orEmpty()
                val name = HADITH_BOOKS.firstOrNull { it.slug == backStackEntry.arguments?.getString("bookSlug") }
                    ?.arabicName ?: rawName
                HadithBookScreen(bookArabicName = name, onBack = { navController.popBackStack() })
            }

            composable(Tab.Adhkar.route) { AdhkarScreen() }
            composable(Tab.Prayer.route) { PrayerScreen() }
            composable("qibla") { QiblaScreen() }
            composable("settings") { SettingsScreen() }
            composable("fiqh") { FiqhScreen() }
            composable("aqeedah") { AqeedahScreen() }
            composable("seerah") { SeerahScreen() }
            composable("profile") { ProfileScreen() }
            composable("search") { SearchScreen() }
            composable("companions") { CompanionsScreen() }
            composable("library") { LibraryScreen() }
            composable("hajj_umrah") { HajjUmrahScreen() }
            composable("ramadan") { RamadanScreen() }

            composable("tools") {
                ToolsScreen(onNavigate = { route -> navController.navigate(route) })
            }
            composable("tool_zakat") { ZakatCalculatorScreen() }
            composable("tool_tasbih") { TasbihScreen() }

            composable(Tab.More.route) {
                MoreScreen(onNavigate = { route -> navController.navigate(route) })
            }
        }
    }
}

@Composable
private fun RashadBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination

    NavigationBar {
        tabs.forEach { tab ->
            val selected = currentRoute?.hierarchy?.any { it.route == tab.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(tab.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) }
            )
        }
    }
}
