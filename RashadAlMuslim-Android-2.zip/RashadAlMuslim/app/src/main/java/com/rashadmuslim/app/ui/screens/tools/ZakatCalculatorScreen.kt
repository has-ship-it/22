package com.rashadmuslim.app.ui.screens.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

// نصاب الذهب والفضة التقريبي المستخدم شائعًا في الفتاوى المعاصرة (بالجرام).
// القيمة بالعملة المحلية تعتمد على سعر الذهب/الفضة الحالي، وهو ما يحتاج تزويد المستخدم
// بسعر الجرام يدويًا حاليًا (لا يوجد مصدر سعر ذهب حيّ مربوط بالتطبيق بعد).
private const val GOLD_NISAB_GRAMS = 85.0
private const val SILVER_NISAB_GRAMS = 595.0
private const val ZAKAT_RATE = 0.025

@Composable
fun ZakatCalculatorScreen() {
    var cash by rememberSaveable { mutableStateOf("") }
    var tradeGoods by rememberSaveable { mutableStateOf("") }
    var debts by rememberSaveable { mutableStateOf("") }
    var goldGramPrice by rememberSaveable { mutableStateOf("") }

    val cashValue = cash.toDoubleOrNull() ?: 0.0
    val tradeValue = tradeGoods.toDoubleOrNull() ?: 0.0
    val debtsValue = debts.toDoubleOrNull() ?: 0.0
    val goldPrice = goldGramPrice.toDoubleOrNull()

    val netWealth = (cashValue + tradeValue - debtsValue).coerceAtLeast(0.0)
    val nisabValue = goldPrice?.times(GOLD_NISAB_GRAMS)
    val zakatDue = if (nisabValue != null && netWealth >= nisabValue) netWealth * ZAKAT_RATE else 0.0

    Scaffold(
        topBar = { TopAppBar(title = { Text("حاسبة الزكاة", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Text(
                "أدخل القيم بعملتك المحلية. هذه الحاسبة تغطي النقود وعروض التجارة فقط حاليًا؛ " +
                    "زكاة الزروع والثمار والأنعام والأسهم تحتاج طريقة حساب مختلفة لكل منها ولم تُضف بعد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LabeledField("النقود المدخرة (حسابات، كاش)", cash) { cash = it }
            LabeledField("قيمة عروض التجارة (بضاعة للبيع)", tradeGoods) { tradeGoods = it }
            LabeledField("الديون المستحقة عليك (تُطرح من الوعاء)", debts) { debts = it }
            LabeledField("سعر جرام الذهب الحالي بعملتك", goldGramPrice) { goldGramPrice = it }

            Card(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(18.dp)) {
                    if (goldPrice == null) {
                        Text(
                            "أدخل سعر جرام الذهب لحساب النصاب والزكاة المستحقة.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        Text("الوعاء الزكوي: ${"%.2f".format(netWealth)}", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "قيمة النصاب (85 جم ذهب): ${"%.2f".format(nisabValue)}",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Text(
                            if (zakatDue > 0) "الزكاة المستحقة (2.5%): ${"%.2f".format(zakatDue)}"
                            else "لم يبلغ المال النصاب، فلا زكاة واجبة حاليًا.",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }
                }
            }

            Text(
                "طريقة الحساب: الزكاة تجب إذا بلغ صافي المال (بعد طرح الديون) نصاب 85 جرامًا من " +
                    "الذهب تقريبًا، وحال عليه حول قمري كامل، وتُحسب بنسبة 2.5%. يُشترط أيضًا مرور " +
                    "حول هجري كامل على بلوغ النصاب — وهذا الشرط غير محسوب تلقائيًا هنا بعد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}

@Composable
private fun LabeledField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.all { c -> c.isDigit() || c == '.' }) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
    )
}
