package com.rashadmuslim.app.ui.screens.library

import android.app.Application
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.LibraryBook
import com.rashadmuslim.app.data.repository.EducationalContentRepository

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    val books = EducationalContentRepository(app).loadLibrary().books
    val categories = listOf("الكل") + books.map { it.category }.distinct()
}

@Composable
fun LibraryScreen(viewModel: LibraryViewModel = viewModel()) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf("الكل") }

    val filtered = remember(query, selectedCategory, viewModel.books) {
        viewModel.books.filter { book ->
            val matchesQuery = query.isBlank() ||
                book.title.contains(query) ||
                book.author.contains(query)
            val matchesCategory = selectedCategory == "الكل" || book.category == selectedCategory
            matchesQuery && matchesCategory
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("المكتبة الإسلامية", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("ابحث عن كتاب أو مؤلف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )

            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                items(viewModel.categories) { category ->
                    val isSelected = category == selectedCategory
                    Card(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clickable { selectedCategory = category },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Text(
                            category,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isSelected)
                                MaterialTheme.colorScheme.onPrimary
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Text(
                "فهرس أولي لعدد من الكتب الإسلامية المعتمدة — بيانات تعريفية فقط دون نص الكتاب الكامل، وسيُستكمل تدريجيًا.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(horizontal = 16.dp, bottom = 8.dp)
            )

            LazyColumn {
                items(filtered, key = { it.id }) { book ->
                    LibraryBookCard(book)
                }
            }
        }
    }
}

@Composable
private fun LibraryBookCard(book: LibraryBook) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .animateContentSize()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(book.title, style = MaterialTheme.typography.titleMedium)
            Text(
                "المؤلف: ${book.author}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
            Row(Modifier.padding(top = 4.dp)) {
                Text(
                    book.category,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Text(
                    "  •  ${book.pages} صفحة",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }
            if (expanded) {
                Text(
                    book.description,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}
