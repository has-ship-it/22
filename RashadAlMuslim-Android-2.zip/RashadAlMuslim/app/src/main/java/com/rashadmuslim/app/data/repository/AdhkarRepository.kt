package com.rashadmuslim.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.rashadmuslim.app.data.model.AdhkarRoot

/**
 * الأذكار مجموعة مختارة (غير شاملة) محفوظة محليًا ضمن assets/adhkar_seed.json،
 * بصيغ موثّقة ومعروفة (لا تحتاج شبكة ولا مصدرًا خارجيًا). هذه مجموعة أولية تمثيلية
 * فقط من كل تصنيف — إكمال بقية الأذكار (حصن المسلم كاملًا) يحتاج مراجعة شرعية
 * لضمان دقة كل نص ورقمه قبل إضافته.
 */
class AdhkarRepository(private val context: Context) {

    fun loadAll(): AdhkarRoot {
        val json = context.assets.open("adhkar_seed.json").bufferedReader().use { it.readText() }
        return Gson().fromJson(json, AdhkarRoot::class.java)
    }
}
