package com.rashadmuslim.app.ui.screens.settings

import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberPermissionState
import com.rashadmuslim.app.data.PrayerKey
import com.rashadmuslim.app.data.arabicName

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel()) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()

    val soundPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        viewModel.setCustomSoundUri(uri?.toString())
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("الإعدادات", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            SectionTitle("اللغة")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ar"))
                }) { Text("العربية") }
                OutlinedButton(onClick = {
                    AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en"))
                }) { Text("English") }
            }
            Text(
                "ملاحظة: تغيير اللغة يبدّل اتجاه النظام وبعض البيانات (كأسماء السور)، أما نصوص الواجهة" +
                    " نفسها فلا تزال عربية فقط في هذا الإصدار المبكر.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(top = 6.dp, bottom = 20.dp)
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val notifPermission = rememberPermissionState(android.Manifest.permission.POST_NOTIFICATIONS)
                if (notifPermission.status != PermissionStatus.Granted) {
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("إشعارات الأذان معطّلة من نظام أندرويد حاليًا", style = MaterialTheme.typography.bodyMedium)
                            Button(
                                onClick = { notifPermission.launchPermissionRequest() },
                                modifier = Modifier.padding(top = 8.dp)
                            ) { Text("السماح بالإشعارات") }
                        }
                    }
                }
            }

            SectionTitle("تنبيهات الأذان")
            val s = settings
            if (s != null) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("تفعيل تنبيهات الأذان", style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = s.notificationsEnabled, onCheckedChange = viewModel::setNotificationsEnabled)
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp))

                PrayerKey.entries.forEach { prayer ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(prayer.arabicName, style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = prayer in s.enabledPrayers,
                            onCheckedChange = { viewModel.setPrayerEnabled(prayer, it) },
                            enabled = s.notificationsEnabled
                        )
                    }
                }

                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("صوت الأذان", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (s.customSoundUri != null) "تم اختيار صوت مخصّص من جهازك" else "صوت الإشعار الافتراضي للنظام",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        val intent = android.content.Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر صوت الأذان")
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        }
                        soundPicker.launch(intent)
                    }) { Text("اختيار من الجهاز") }

                    if (s.customSoundUri != null) {
                        OutlinedButton(onClick = { viewModel.setCustomSoundUri(null) }) {
                            Text("إعادة الافتراضي")
                        }
                    }
                }
                Text(
                    "ملاحظة: لا تتوفر أصوات أذان لمؤذنين معيّنين مضمّنة في التطبيق لأسباب تتعلق بحقوق" +
                        " التسجيلات الصوتية. يمكنك اختيار أي ملف صوتي محفوظ على جهازك.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 10.dp)
    )
}
