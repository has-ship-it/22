package com.rashadmuslim.app.ui.screens.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalLibrary
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class MoreEntry(val label: String, val icon: ImageVector, val route: String)

private val ENTRIES = listOf(
    MoreEntry("الحديث", Icons.Filled.AutoStories, "hadith_books"),
    MoreEntry("الفقه", Icons.Filled.Balance, "fiqh"),
    MoreEntry("العقيدة", Icons.Filled.Psychology, "aqeedah"),
    MoreEntry("السيرة", Icons.Filled.History, "seerah"),
    MoreEntry("الصحابة", Icons.Filled.Groups, "companions"),
    MoreEntry("المكتبة", Icons.Filled.LocalLibrary, "library"),
    MoreEntry("الحج والعمرة", Icons.Filled.Place, "hajj_umrah"),
    MoreEntry("رمضان", Icons.Filled.NightlightRound, "ramadan"),
    MoreEntry("القبلة", Icons.Filled.MenuBook, "qibla"),
    MoreEntry("الصلاة", Icons.Filled.Mosque, "prayer"),
    MoreEntry("أدوات المسلم", Icons.Filled.Build, "tools"),
    MoreEntry("البحث الإسلامي", Icons.Filled.Search, "search"),
    MoreEntry("الملف الشخصي", Icons.Filled.Person, "profile"),
    MoreEntry("الإعدادات", Icons.Filled.Settings, "settings"),
)

@Composable
fun MoreScreen(onNavigate: (String) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("المزيد", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
        ) {
            items(ENTRIES) { entry ->
                Card(
                    modifier = Modifier.padding(6.dp).clickable { onNavigate(entry.route) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(entry.icon, contentDescription = entry.label, tint = MaterialTheme.colorScheme.primary)
                        Text(entry.label, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }
}
