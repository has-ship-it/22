package com.rashadmuslim.app.data.model

data class AdhkarRoot(val categories: List<AdhkarCategory>)

data class AdhkarCategory(
    val id: String,
    val nameAr: String,
    val items: List<AdhkarItem>
)

data class AdhkarItem(
    val text: String,
    val repeat: Int,
    val source: String
)
