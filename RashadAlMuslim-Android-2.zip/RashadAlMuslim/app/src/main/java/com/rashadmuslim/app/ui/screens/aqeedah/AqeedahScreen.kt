package com.rashadmuslim.app.ui.screens.aqeedah

import android.app.Application
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.AqeedahUnit
import com.rashadmuslim.app.data.repository.EducationalContentRepository

class AqeedahViewModel(app: Application) : AndroidViewModel(app) {
    val units = EducationalContentRepository(app).loadAqeedah().units
}

@Composable
fun AqeedahScreen(viewModel: AqeedahViewModel = viewModel()) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("العقيدة", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        LazyColumn(Modifier.fillMaxWidth().padding(padding)) {
            items(viewModel.units, key = { it.id }) { unit ->
                UnitCard(unit)
            }
        }
    }
}

@Composable
private fun UnitCard(unit: AqeedahUnit) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .animateContentSize()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(unit.nameAr, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            if (expanded) {
                Text(unit.summary, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 10.dp))
                Text(
                    "الأدلة: ${unit.evidenceSummary}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 8.dp)
                )
                unit.scholarlyDifference?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            } else {
                Text(
                    unit.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    maxLines = 2,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
