package com.rashadmuslim.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar

val Context.profileDataStore by preferencesDataStore(name = "profile_stats")

data class ProfileStats(
    val daysUsed: Int,
    val hadithsRead: Int,
    val dhikrCompleted: Int
)

/**
 * إحصائيات محلية بسيطة خاصة بالمستخدم على جهازه فقط (لا مزامنة، لا مقارنة بمستخدمين
 * آخرين)، تحسب أيام الاستخدام الفعلية وعدد مرات فتح أقسام معينة كمؤشر تقريبي للنشاط.
 */
class ProfileStatsRepository(private val context: Context) {

    private object Keys {
        val LAST_OPEN_DAY = longPreferencesKey("last_open_epoch_day")
        val DAYS_USED = intPreferencesKey("days_used")
        val HADITHS_READ = intPreferencesKey("hadiths_read")
        val DHIKR_COMPLETED = intPreferencesKey("dhikr_completed")
    }

    val statsFlow: Flow<ProfileStats> = context.profileDataStore.data.map { prefs ->
        ProfileStats(
            daysUsed = prefs[Keys.DAYS_USED] ?: 0,
            hadithsRead = prefs[Keys.HADITHS_READ] ?: 0,
            dhikrCompleted = prefs[Keys.DHIKR_COMPLETED] ?: 0
        )
    }

    suspend fun recordAppOpenIfNewDay() {
        val today = Calendar.getInstance().let {
            it.get(Calendar.YEAR) * 1000 + it.get(Calendar.DAY_OF_YEAR)
        }.toLong()
        context.profileDataStore.edit { prefs ->
            val lastDay = prefs[Keys.LAST_OPEN_DAY]
            if (lastDay != today) {
                prefs[Keys.LAST_OPEN_DAY] = today
                prefs[Keys.DAYS_USED] = (prefs[Keys.DAYS_USED] ?: 0) + 1
            }
        }
    }

    suspend fun incrementDhikrCompleted() {
        context.profileDataStore.edit { prefs ->
            prefs[Keys.DHIKR_COMPLETED] = (prefs[Keys.DHIKR_COMPLETED] ?: 0) + 1
        }
    }
}
