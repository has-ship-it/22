package com.rashadmuslim.app.data.model

// ===== الفقه =====
data class FiqhRoot(val topics: List<FiqhTopic>)
data class FiqhTopic(val id: String, val nameAr: String, val icon: String, val issues: List<FiqhIssue>)
data class FiqhIssue(
    val title: String,
    val ruling: String,
    val evidenceSummary: String,
    val scholarlyDifference: String?
)

// ===== العقيدة =====
data class AqeedahRoot(val units: List<AqeedahUnit>)
data class AqeedahUnit(
    val id: String,
    val nameAr: String,
    val summary: String,
    val evidenceSummary: String,
    val scholarlyDifference: String? = null
)

// ===== السيرة =====
data class SeerahRoot(val events: List<SeerahEvent>)
data class SeerahEvent(
    val id: String,
    val title: String,
    val periodLabel: String,
    val summary: String,
    val sourceNote: String
)
