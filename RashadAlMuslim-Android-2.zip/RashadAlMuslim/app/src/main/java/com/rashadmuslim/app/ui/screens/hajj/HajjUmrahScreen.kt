package com.rashadmuslim.app.ui.screens.hajj

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.ChecklistStep
import com.rashadmuslim.app.data.HajjUmrahRepository
import com.rashadmuslim.app.data.HajjUmrahSteps
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HajjUmrahViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = HajjUmrahRepository(app)

    val umrahDone: StateFlow<Set<String>> = repo.umrahDoneFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())
    val hajjDone: StateFlow<Set<String>> = repo.hajjDoneFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    fun toggleUmrah(id: String) = viewModelScope.launch { repo.toggleUmrahStep(id) }
    fun toggleHajj(id: String) = viewModelScope.launch { repo.toggleHajjStep(id) }
    fun resetUmrah() = viewModelScope.launch { repo.resetUmrah() }
    fun resetHajj() = viewModelScope.launch { repo.resetHajj() }
}

@Composable
fun HajjUmrahScreen(viewModel: HajjUmrahViewModel = viewModel()) {
    var selectedTab by rememberSaveable { mutableStateOf(0) }
    val umrahDone by viewModel.umrahDone.collectAsState()
    val hajjDone by viewModel.hajjDone.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("الحج والعمرة", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("العمرة") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("الحج") })
            }

            if (selectedTab == 0) {
                ChecklistSection(
                    steps = HajjUmrahSteps.umrahSteps,
                    doneIds = umrahDone,
                    onToggle = { viewModel.toggleUmrah(it) },
                    onReset = { viewModel.resetUmrah() }
                )
            } else {
                ChecklistSection(
                    steps = HajjUmrahSteps.hajjSteps,
                    doneIds = hajjDone,
                    onToggle = { viewModel.toggleHajj(it) },
                    onReset = { viewModel.resetHajj() }
                )
            }
        }
    }
}

@Composable
private fun ChecklistSection(
    steps: List<ChecklistStep>,
    doneIds: Set<String>,
    onToggle: (String) -> Unit,
    onReset: () -> Unit
) {
    val progress = remember(doneIds, steps) {
        if (steps.isEmpty()) 0f else doneIds.size.toFloat() / steps.size.toFloat()
    }

    Column {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "التقدّم: ${doneIds.size} من ${steps.size}",
                    style = MaterialTheme.typography.bodyMedium
                )
                TextButton(onClick = onReset) { Text("إعادة تعيين") }
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Text(
                "دليل مبسّط يتبع الترتيب العام المعروف للنسك؛ لبعض المسائل تفاصيل وخلافات فقهية معتبرة (كصفة النسك: تمتع/قران/إفراد) تحتاج سؤال أهل العلم حسب حالتك الخاصة.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        LazyColumn {
            items(steps, key = { it.id }) { step ->
                val checked = step.id in doneIds
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (checked)
                            MaterialTheme.colorScheme.primaryContainer
                        else
                            MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.Top
                    ) {
                        Checkbox(checked = checked, onCheckedChange = { onToggle(step.id) })
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(step.title, style = MaterialTheme.typography.titleSmall)
                            Text(
                                step.description,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
