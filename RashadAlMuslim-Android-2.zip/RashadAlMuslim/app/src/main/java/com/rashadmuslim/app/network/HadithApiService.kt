package com.rashadmuslim.app.network

import com.rashadmuslim.app.data.model.HadithEditionResponse
import retrofit2.http.GET
import retrofit2.http.Path

/**
 * واجهة الحديث: مبنية على مشروع fawazahmed0/hadith-api المجاني (بلا مفتاح API)،
 * المستضاف عبر شبكة jsdelivr CDN. التوثيق: https://github.com/fawazahmed0/hadith-api
 * نجلب ملف الكتاب كاملًا مرة واحدة ثم نخزّنه محليًا (Room) ليعمل لاحقًا بلا إنترنت.
 */
interface HadithApiService {
    @GET("gh/fawazahmed0/hadith-api@1/editions/{edition}.min.json")
    suspend fun getEdition(@Path("edition") edition: String): HadithEditionResponse
}
