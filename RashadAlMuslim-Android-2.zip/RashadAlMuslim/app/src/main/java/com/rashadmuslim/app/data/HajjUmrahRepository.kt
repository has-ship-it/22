package com.rashadmuslim.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.hajjUmrahDataStore by preferencesDataStore(name = "hajj_umrah_checklist")

data class ChecklistStep(
    val id: String,
    val title: String,
    val description: String
)

/**
 * خطوات الحج والعمرة كمرجع تعليمي مبسّط يتبع الترتيب العام المعروف لأداء النسكين،
 * مع التنبيه إلى أن تفاصيل بعض المسائل (مثل كيفية التمتع/القران/الإفراد، أو مسائل
 * الحج عن الغير) قد تحتاج سؤال أهل العلم حسب حالة كل معتمر/حاج.
 */
object HajjUmrahSteps {
    val umrahSteps = listOf(
        ChecklistStep("u1", "الإحرام من الميقات", "نية الدخول في النسك مع التلبية، بعد الغسل والتطيب ولبس ملابس الإحرام قبل الوصول إلى الميقات."),
        ChecklistStep("u2", "الطواف بالبيت (7 أشواط)", "الطواف حول الكعبة سبعة أشواط، يبدأ وينتهي عند الحجر الأسود."),
        ChecklistStep("u3", "صلاة ركعتين خلف المقام", "بعد إتمام الطواف، يُستحب صلاة ركعتين خلف مقام إبراهيم إن تيسر، أو في أي موضع من المسجد."),
        ChecklistStep("u4", "السعي بين الصفا والمروة (7 أشواط)", "السعي سبعة أشواط بين جبلي الصفا والمروة، يبدأ من الصفا."),
        ChecklistStep("u5", "الحلق أو التقصير", "قص الشعر أو حلقه، وبه يتم التحلل من الإحرام وتنتهي العمرة.")
    )

    val hajjSteps = listOf(
        ChecklistStep("h1", "الإحرام بنية الحج (8 ذو الحجة)", "الدخول في نسك الحج من مكة أو مكان الإقامة، مع التلبية."),
        ChecklistStep("h2", "الذهاب إلى منى والمبيت فيها", "التوجه إلى منى يوم الثامن والمبيت فيها إلى فجر التاسع (يوم التروية)."),
        ChecklistStep("h3", "الذهاب إلى عرفة والوقوف فيها (9 ذو الحجة)", "الوقوف بعرفة من بعد الظهر إلى غروب الشمس، وهو ركن الحج الأعظم."),
        ChecklistStep("h4", "المبيت في مزدلفة وجمع الحصى", "التوجه إلى مزدلفة بعد غروب شمس يوم عرفة، والمبيت فيها، وجمع حصى الجمرات."),
        ChecklistStep("h5", "رمي جمرة العقبة الكبرى (10 ذو الحجة)", "رمي سبع حصيات متعاقبات في يوم العيد، ثم الحلق أو التقصير."),
        ChecklistStep("h6", "ذبح الهدي (لمن عليه هدي)", "لمن كان متمتعًا أو قارنًا، يذبح هديًا شكرًا، ويوزّعه على الفقراء ويأكل منه."),
        ChecklistStep("h7", "طواف الإفاضة", "الطواف بالبيت بعد التحلل من الإحرام، وهو ركن من أركان الحج."),
        ChecklistStep("h8", "أيام التشريق والمبيت في منى (11-13 ذو الحجة)", "المبيت في منى ورمي الجمرات الثلاث كل يوم، مع إمكانية التعجل بالخروج بعد اليوم الثاني لمن أراد."),
        ChecklistStep("h9", "طواف الوداع", "طواف وداع البيت قبل مغادرة مكة لمن ليس من أهلها، آخر عمل يؤديه الحاج قبل السفر.")
    )
}

/**
 * يتتبع الخطوات المكتملة محليًا فقط على الجهاز (بدون أي مزامنة أو مشاركة)، كمساعد
 * شخصي لمتابعة تقدّم أداء النسك أثناء رحلة الحج أو العمرة.
 */
class HajjUmrahRepository(private val context: Context) {

    private object Keys {
        val UMRAH_DONE = stringSetPreferencesKey("umrah_done_steps")
        val HAJJ_DONE = stringSetPreferencesKey("hajj_done_steps")
    }

    val umrahDoneFlow: Flow<Set<String>> =
        context.hajjUmrahDataStore.data.map { it[Keys.UMRAH_DONE] ?: emptySet() }

    val hajjDoneFlow: Flow<Set<String>> =
        context.hajjUmrahDataStore.data.map { it[Keys.HAJJ_DONE] ?: emptySet() }

    suspend fun toggleUmrahStep(stepId: String) {
        context.hajjUmrahDataStore.edit { prefs ->
            val current = prefs[Keys.UMRAH_DONE] ?: emptySet()
            prefs[Keys.UMRAH_DONE] = if (stepId in current) current - stepId else current + stepId
        }
    }

    suspend fun toggleHajjStep(stepId: String) {
        context.hajjUmrahDataStore.edit { prefs ->
            val current = prefs[Keys.HAJJ_DONE] ?: emptySet()
            prefs[Keys.HAJJ_DONE] = if (stepId in current) current - stepId else current + stepId
        }
    }

    suspend fun resetUmrah() {
        context.hajjUmrahDataStore.edit { prefs -> prefs[Keys.UMRAH_DONE] = emptySet() }
    }

    suspend fun resetHajj() {
        context.hajjUmrahDataStore.edit { prefs -> prefs[Keys.HAJJ_DONE] = emptySet() }
    }
}
