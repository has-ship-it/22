package com.rashadmuslim.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.rashadmuslim.app.data.model.AqeedahRoot
import com.rashadmuslim.app.data.model.CompanionsRoot
import com.rashadmuslim.app.data.model.FiqhRoot
import com.rashadmuslim.app.data.model.LibraryRoot
import com.rashadmuslim.app.data.model.SeerahRoot

/**
 * محتوى تعليمي ثابت (فقه/عقيدة/سيرة) محفوظ محليًا ضمن assets/*.json، يعمل بالكامل دون
 * إنترنت. هذه مجموعة أولية تمثيلية من كل قسم فقط — تحتاج توسعة تدريجية مستقبلًا
 * بمراجعة شرعية لكل إضافة جديدة.
 */
class EducationalContentRepository(private val context: Context) {
    private val gson = Gson()

    fun loadFiqh(): FiqhRoot =
        gson.fromJson(readAsset("fiqh_seed.json"), FiqhRoot::class.java)

    fun loadAqeedah(): AqeedahRoot =
        gson.fromJson(readAsset("aqeedah_seed.json"), AqeedahRoot::class.java)

    fun loadSeerah(): SeerahRoot =
        gson.fromJson(readAsset("seerah_seed.json"), SeerahRoot::class.java)

    fun loadCompanions(): CompanionsRoot =
        gson.fromJson(readAsset("companions_seed.json"), CompanionsRoot::class.java)

    fun loadLibrary(): LibraryRoot =
        gson.fromJson(readAsset("library_seed.json"), LibraryRoot::class.java)

    private fun readAsset(name: String): String =
        context.assets.open(name).bufferedReader().use { it.readText() }
}
