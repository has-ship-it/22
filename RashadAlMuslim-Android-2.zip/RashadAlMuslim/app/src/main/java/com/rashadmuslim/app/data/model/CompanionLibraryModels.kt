package com.rashadmuslim.app.data.model

data class CompanionsRoot(val companions: List<Companion>)
data class Companion(
    val id: String,
    val name: String,
    val title: String,
    val bio: String,
    val notableEvents: String,
    val sourceNote: String
)

data class LibraryRoot(val books: List<LibraryBook>)
data class LibraryBook(
    val id: String,
    val title: String,
    val author: String,
    val category: String,
    val pages: Int,
    val description: String
)
